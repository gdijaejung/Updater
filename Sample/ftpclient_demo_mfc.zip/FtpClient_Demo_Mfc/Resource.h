//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FTPexample.rc
//
#define IDD_FTP_DLG_EXAMPLE             102
#define IDR_MAINFRAME                   128
#define IDD_FTP_DLG_BROWSE              129
#define IDD_FTP_DLG_LOGON_INFO          130
#define IDD_FTP_DLG_PROGRESS            132
#define IDR_DOWNLOAD                    133
#define IDR_AVI2                        134
#define IDR_UPLOAD                      134
#define IDR_AVI_UPLOAD                  134
#define IDR_AVI1                        135
#define IDR_AVI_FILECOPY                136
#define IDR_AVI_DOWNLOAD                137
#define IDC_FTP_TREE                    1000
#define IDC_BTN_BROWSE                  1001
#define IDC_BTN_LOGON_INFO              1002
#define IDC_RE_PROTOCOL                 1003
#define IDC_PROGRESS_BAR                1004
#define IDC_ANIMATE_FILECOPY            1005
#define IDC_STATIC_FILESTATUS           1006
#define IDC_STATIC_SOURCE_FILE          1007
#define IDC_STATIC_TARGET_FILE          1008
#define ID_ABORT_FTP_TRANSFER           1009
#define IDC_ACCOUNT                     18434
#define IDC_ANONYMOUS                   18438
#define IDC_FIREWALL                    18450
#define IDC_FRAME_FIREWALL              18451
#define IDC_HOSTNAME                    18453
#define IDC_HOSTNAME_FIREWALL           18454
#define IDC_HOSTNAME_STATIC             18455
#define IDC_PASSWORD                    18460
#define IDC_PASSWORD_FIREWALL           18461
#define IDC_PASSWORD_STATIC             18462
#define IDC_PASV                        18463
#define IDC_PORT                        18464
#define IDC_PORT_FIREWALL               18465
#define IDC_PORT_STATIC                 18466
#define IDC_TYPE_FIREWALL               18475
#define IDC_TYPE_STATIC                 18476
#define IDC_USER                        18477
#define IDC_USER_FIREWALL               18478
#define IDC_USER_STATIC                 18479

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
